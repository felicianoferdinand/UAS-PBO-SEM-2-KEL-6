from flask import Blueprint
from flask_restful import Api
from resource.user import RegisterAPI, LoginAPI, UserAPI, AllUsersAPI


authz_blueprint = Blueprint("user_api", __name__)
authz_blueprint_api = Api(authz_blueprint)

authz_blueprint_api.add_resource(
    RegisterAPI, "/user"
)
authz_blueprint_api.add_resource(
    LoginAPI, "/login"
)
authz_blueprint_api.add_resource(UserAPI, "/user/<string:user_id>")
authz_blueprint_api.add_resource(AllUsersAPI, "/users")
