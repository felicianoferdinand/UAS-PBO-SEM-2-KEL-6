# app/route/hello.py

from flask import Blueprint

hello_blueprint = Blueprint('hello_api', __name__)

@hello_blueprint.route('/hello-world')
def hello_world():
    return 'Hello, World!'
