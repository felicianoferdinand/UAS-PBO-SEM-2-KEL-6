#!/bin/sh
sh -c "python wsgi.py"